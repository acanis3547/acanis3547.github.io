package Java.finalx;

import java.util.ArrayList;

public class Project {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Catalog rental = new Catalog("킥보드 렌탈 시스템");
		KickBoard k1 = new KickBoard();
		KickBoard k2 = new KickBoard();
		KickBoard k3 = new KickBoard();
		KickBoard k4 = new KickBoard();
		k1.setId("02-001");
		k2.setId("032-001");
		k3.setId("032-002");
		k4.setId("042-001");
	
		Account acc1 = new Account("1",96000);
		Account acc2 = new Account("2",5000);
		acc1.setAccId("202X1001");
		acc2.setAccId("202X1002");
		acc1.setName("이한서");
		acc2.setName("위준명");
		
		rental.addKickboard(k1);
		rental.addKickboard(k2);
		rental.addKickboard(k3);
		rental.addKickboard(k4);
		
		rental.addAccount(acc1);
		rental.addAccount(acc2);
		
		System.out.println("킥보드 랜탈 시스템 생성");
		rental.printStatus();
		rental.checkOut(k1, acc2);
		rental.printStatus();
		rental.checkIn(k1);
		rental.checkOut(k2, acc2);
		rental.printStatus();
		rental.checkOut(k3, acc2);
		rental.checkIn(k2);
		rental.printStatus();
		rental.checkOut(k4, acc2);
		rental.printStatus();
		rental.checkOut(k2, acc1);
		rental.printStatus();

	}

}

class KickBoard {
	private String kickboard_id; 
	private int rental_cash = 1500; 
	private Account account;
	
	public  KickBoard() {}
	
	
	public  KickBoard(String id) {this.kickboard_id = id;}
	
	public void setId(String isbn) {this.kickboard_id = isbn;}
	public String getId() {return this.kickboard_id;}
	
	
	public void setCash(int remains) {this.rental_cash = remains;}
	public int getrental() { return this.rental_cash;}
	
	public void setAccount(Account student) {this.account = student;}
	public Account getAccount() {return this.account;}
	
	public String toString() {
		String available;
		if (this.getAccount() == null) {
			available = "랜탈가능";
		}
		else {
			available = "렌탈 불가";
		}
		return "식별번호="+this.getId()+",손님= "+this.getAccount()+","+available;
	}
}

class Catalog {
	public String catalogname; public ArrayList<KickBoard> kickboards; public ArrayList<Account> accounts;
	public Catalog(String CatalogName) {
		this.catalogname = CatalogName; kickboards = new ArrayList<KickBoard>(); accounts = new ArrayList<Account>();
	}
	public String getlogName() {
		return this.catalogname;
	}
	public ArrayList<KickBoard> getBoards(){
		return this.kickboards;
	}
	public ArrayList<Account> getAccounts(){
		return this.accounts;
	}
	public void addKickboard(KickBoard kickboards) {
		this.kickboards.add(kickboards);
	}
	public void removeKickboard(KickBoard kickboards) {
		this.kickboards.remove(kickboards);
	}
	public void addAccount(Account account) {
		this.accounts.add(account);
	}
	public void removeAccount(Account account) {
	this.accounts.remove(account);
	}
	
	public boolean checkOut(KickBoard kickboards, Account account) {
		int boardsOut = kickboards.getrental();
		if(kickboards.getAccount() == null) 
		{
			if(boardsOut< account.getMaxCharge()) 
			{
				kickboards.setAccount(account);
				System.out.println("킥보드 "+kickboards.getId()+" 를 "
						+account.getName()+"에게 랜탈해줌");
				account.setMaxCharge(account.getMaxCharge()-1500);
				return true;
			}
			else {
				System.out.println("킥보드"+kickboards.getId()+" 는 대출 가능하나 "
			+account.getName()+"님의 잔액("+account.getMaxCharge()+")이 부족하여"+" 랜탈 불가");
				return false;
			}
		
		}
		else 
		{
			System.out.println("킥보드 "+kickboards.getId()+"은 이미 빌리고 있어 "+account.getName()+"님이 랜탈 불가능 합니다.");
			return false;
		}
		
	}
	
	
	public boolean checkIn(KickBoard kickboards) {
		if (kickboards.getAccount() != null) {
			kickboards.setAccount(null);
			System.out.println("킥보드 "+kickboards.getId()+"는 반환 되었습니다.");
			return true;
		}
		else {
			return false;
		}
	}
	
	public ArrayList<KickBoard> getBoardsForAccount(Account account){
		ArrayList<KickBoard> result = new ArrayList<KickBoard>();
		for(KickBoard aKickboard : this.getBoards()) {
			if((aKickboard.getAccount() != null)&&(aKickboard.getAccount().getAccNumber().equals(account.getAccNumber()))) {
				result.add(aKickboard);
			}
		}
		return result;
	}
	
	public ArrayList<KickBoard> getAvailableKickboards(){
		ArrayList<KickBoard> result = new ArrayList<KickBoard>();
		for(KickBoard aKickboard : this.getBoards()) 
		{
			if (aKickboard.getAccount() == null) 
			{
				result.add(aKickboard);
			}
		}
		return result;
	}
	 
	public ArrayList<KickBoard> getUnavailableKickboards(){
		ArrayList<KickBoard> result = new ArrayList<KickBoard>();
		for(KickBoard aKickboard : this.getBoards()) {
			if(aKickboard.getAccount() != null) {
				result.add(aKickboard);
			}
		}
		return result;
	}
	
	
	public String toString() {
	
		return this.getlogName()+"의  킥보드 수="+
	(this.getBoards().size())+"대, 회원수="+
				this.getAccounts().size()+"명";
	}
	public void printStatus() {
		System.out.println("--- 랜탈 현황 ---\n"+this.toString());
		for(KickBoard aKickboard : this.getBoards()) {
			System.out.println(aKickboard);
			
		}
		for(Account account : this.getAccounts()) {
			int count = this.getBoardsForAccount(account).size();
			System.out.println(account+" 은/는 "+ count + "대 랜탈중");
		}
		System.out.println("현재 랜탈 가능 킥보드: "+ this.getAvailableKickboards().size());
		System.out.println("---종료 ---");
	}
}



class Account {
	private String name;
	private String acc_id;
	private int charged_cash;
	
	public Account() {}
	public Account(String accNumber, int cash) { this.acc_id= accNumber; this.charged_cash = cash;}
	
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getAccNumber() {
		return this.acc_id;
	}
	public void setAccId(String accNumber) {
		this.acc_id = accNumber;
	}
	
	public int getMaxCharge() {
		return charged_cash;
	}
	public void setMaxCharge(int maxCharge) {
		this.charged_cash = maxCharge;
	}
	public String toString() {
		return this.getName()+" (최대"+this.getMaxCharge()+"액 이용 가능)";	}
}

		
